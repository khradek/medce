
CKEDITOR.editorConfig = function(config) {
  config.language = 'en';
  config.width = '100%';
  config.height = '800';
  config.enterMode = CKEDITOR.ENTER_BR;
  config.filebrowserBrowseUrl = "/ckeditor/attachment_files";
  config.filebrowserImageBrowseLinkUrl = "/ckeditor/pictures";
  config.filebrowserImageBrowseUrl = "/ckeditor/pictures";
  config.filebrowserImageUploadUrl = "/ckeditor/pictures";
  config.filebrowserUploadUrl = "/ckeditor/attachment_files";
  config.stylesSet = [{ name: 'Double Space', element: 'p', styles: {'line-height': '2.0' }}, { name: 'Red Title' , element: 'h3', styles: { 'color': 'Red' } }, { name: 'Marker: Yellow', element: 'span', styles: { 'background-color': 'Yellow' } }]
  config.removePlugins = 'elementspath';

  config.toolbar_mini = [
    ["Bold",  "Italic",  "Underline",  "Strike",  "-"],
    ['BulletedList','NumberedList' ],['Outdent','Indent'],
   ];

  config.toolbar_Pure = [
    '/', {
      name: 'basicstyles',
      items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'RemoveFormat']
    }, {
      name: 'paragraph',
      items: ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'BidiLtr', 'BidiRtl']
    }, {
      name: 'links',
      items: ['Link', 'Unlink']
    }, '/', {
      name: 'styles',
      items: ['Styles', 'Format', 'Font', 'FontSize']
    }, {
      name: 'colors',
      items: ['TextColor', 'BGColor']
    }, {
      name: 'insert',
      items: ['Image', 'Table', 'HorizontalRule', 'PageBreak']
    }
  ];
  config.toolbar = 'Pure';

  return true;

}


;
